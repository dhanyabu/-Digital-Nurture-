package eCommercePlatformSearchFunction;

import java.util.Arrays;
import java.util.Comparator;

public class Main {
    public static void main(String[] args) {
        Product[] products = {
            new Product(101, "Laptop", "Electronics"),
            new Product(102, "Shampoo", "Beauty"),
            new Product(103, "Table", "Furniture"),
            new Product(104, "Phone", "Electronics"),
            new Product(105, "Shoes", "Fashion")
        };

    
        Arrays.sort(products, Comparator.comparing(p -> p.productName.toLowerCase()));

        Product foundLinear = Search.linearSearch(products, "Phone");
        Product foundBinary = Search.binarySearch(products, "Phone");

        System.out.println("Linear Search Result: " + (foundLinear != null ? foundLinear : "Not Found"));
        System.out.println("Binary Search Result: " + (foundBinary != null ? foundBinary : "Not Found"));
    }
}

