/**
 * 
 */
/**
 * 
 */
module SingletonPatternExample {
}