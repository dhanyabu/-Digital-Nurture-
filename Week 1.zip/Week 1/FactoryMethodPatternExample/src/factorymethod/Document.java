package factorymethod;

public interface Document {
	void open();
}
