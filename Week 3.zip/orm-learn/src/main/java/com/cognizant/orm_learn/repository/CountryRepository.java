package com.cognizant.orm_learn.repository;

import java.util.Date;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.cognizant.orm_learn.model.Country;

@Repository
public interface CountryRepository extends JpaRepository<Country, String> {
    Country findByCode(String code);  // Find by country code
    List<Country> findByNameContainingIgnoreCase(String partialName); 
    // Find by partial name
 // 1. Containing text
    List<Country> findByNameContaining(String keyword);

    // 2. Starting with text
    List<Country> findByNameStartingWith(String prefix);

    // 3. Ending with text
    List<Country> findByNameEndingWith(String suffix);

    // 4. Sorting by name ascending
    List<Country> findAllByOrderByNameAsc();

    // 5. Fetch between dates
    List<Country> findByCreatedDateBetween(Date startDate, Date endDate);

    // 6. Greater than or less than a date
    List<Country> findByCreatedDateAfter(Date date);
    List<Country> findByCreatedDateBefore(Date date);

    // 7. Top countries
    List<Country> findTop3ByOrderByNameAsc();
}


