package com.cognizant.orm_learn.model;


import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "country")
public class Country {

    @Id
    private String code;

    private String name;

    @OneToMany(mappedBy = "country", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private List<State> states;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
        name = "country_language",
        joinColumns = @JoinColumn(name = "country_code"),
        inverseJoinColumns = @JoinColumn(name = "language_id")
    )
    private List<Language> languages;

	public char[] getName() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setCode(String string) {
		// TODO Auto-generated method stub
		
	}

	public void setName(String string) {
		// TODO Auto-generated method stub
		
	}

	public String getCode() {
		// TODO Auto-generated method stub
		return null;
	}

    // Getters and Setters
}
