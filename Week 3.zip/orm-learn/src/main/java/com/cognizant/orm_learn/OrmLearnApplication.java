package com.cognizant.orm_learn;

import java.util.Date;
import java.util.List;
import java.text.SimpleDateFormat;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.cognizant.orm_learn.model.Country;
import com.cognizant.orm_learn.repository.CountryRepository;
import com.cognizant.orm_learn.service.CountryService;
import com.cognizant.orm_learn.service.exception.CountryNotFoundException;

@SpringBootApplication
public class OrmLearnApplication {

    private static final Logger LOGGER = LoggerFactory.getLogger(OrmLearnApplication.class);

    // Static reference to CountryService
    private static CountryService countryService;

    public static void main(String[] args) throws Exception {
        // ✅ Set ApplicationContext and initialize CountryService from Spring container
        ApplicationContext context = SpringApplication.run(OrmLearnApplication.class, args);
        LOGGER.info("Inside main");

        countryService = context.getBean(CountryService.class);  
        // ✅ Get the service bean
        CountryRepository countryRepository = context.getBean(CountryRepository.class);
        testQueryMethods(countryRepository);
        getAllCountriesTest();
        testAddCountry(countryService);
        testUpdateCountry();
        testFindCountryByCode();
        testFindCountriesByPartialName();
        testDeleteCountry();// ✅ Call the test method
    }

    private static void testGetAllCountries() {
        LOGGER.info("Start");
        List<Country> countries = countryService.getAllCountries();
        LOGGER.debug("countries={}", countries);
        LOGGER.info("End");
    }
    
    public static void testAddCountry(CountryService countryService) throws CountryNotFoundException {
        System.out.println("Start... testAddCountry");

        // Step 1: Create new country instance
        Country country = new Country();
        country.setCode("BR");
        country.setName("Brazil");

        // Step 2: Add the country
        countryService.addCountry(country);
        System.out.println("Country added successfully.");

        Country result = countryService.findCountryByCode("BR");
		System.out.println("Fetched Country: Code = " + result.getCode() + ", Name = " + result.getName());

        System.out.println("End... testAddCountry");
    }

    private static void testUpdateCountry() {
        countryService.updateCountry("JP", "Nippon");
        LOGGER.debug("Updated country name for JP");
    }

    private static void testDeleteCountry() {
        countryService.deleteCountry("JP");
        LOGGER.debug("Deleted country with code JP");
    }

    private static void testFindCountryByCode() {
        Country country = countryService.findCountryByCode("IN");
        LOGGER.debug("Found country: {}", country);
    }

    private static void testFindCountriesByPartialName() {
        List<Country> countries = countryService.findCountriesByPartialName("Uni");
        LOGGER.debug("Countries matching 'Uni': {}", countries);
    }
    private static void getAllCountriesTest() {
        LOGGER.info("Start");
        Country country = countryService.findCountryByCode("IN");
        LOGGER.debug("Country:{}", country);
        LOGGER.info("End");
    }
    
   

    public static void testQueryMethods(CountryRepository repository) throws Exception {
        System.out.println("\n--- Query Method Tests ---");

        System.out.println("1. Countries containing 'an':");
        repository.findByNameContaining("an").forEach(c -> System.out.println(c.getName()));

        System.out.println("\n2. Countries starting with 'In':");
        repository.findByNameStartingWith("In").forEach(c -> System.out.println(c.getName()));

        System.out.println("\n3. Countries ordered by name:");
        repository.findAllByOrderByNameAsc().forEach(c -> System.out.println(c.getName()));

        System.out.println("\n4. Countries created between 2023-01-01 and 2025-01-01:");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date from = sdf.parse("2023-01-01");
        Date to = sdf.parse("2025-01-01");
        repository.findByCreatedDateBetween(from, to).forEach(c -> System.out.println(c.getName()));

        System.out.println("\n5. Countries created after 2024-01-01:");
        Date after = sdf.parse("2024-01-01");
        repository.findByCreatedDateAfter(after).forEach(c -> System.out.println(c.getName()));

        System.out.println("\n6. Top 3 countries by name:");
        repository.findTop3ByOrderByNameAsc().forEach(c -> System.out.println(c.getName()));

        System.out.println("\n--- End of Query Tests ---");
    }
    
    

}
