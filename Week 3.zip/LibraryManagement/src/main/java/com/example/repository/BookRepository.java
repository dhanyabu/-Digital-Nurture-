package com.example.repository;

public class BookRepository {
    public void save() {
        System.out.println("Book saved to the repository.");
    }
}
