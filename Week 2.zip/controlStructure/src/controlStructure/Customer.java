package controlStructure;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

class Customer {
    int id;
    String name;
    int age;
    double balance;
    boolean isVIP;
    double loanInterestRate;

    Customer(int id, String name, int age, double balance, double loanInterestRate) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.balance = balance;
        this.loanInterestRate = loanInterestRate;
        this.isVIP = false;
    }
}