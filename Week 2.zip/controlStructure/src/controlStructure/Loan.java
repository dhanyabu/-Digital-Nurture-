package controlStructure;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;


class Loan {
    int customerId;
    LocalDate dueDate;

    Loan(int customerId, LocalDate dueDate) {
        this.customerId = customerId;
        this.dueDate = dueDate;
    }
}