package controlStructure;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;



public class BankOperations{
    public static void main(String[] args) {
        List<Customer> customers = new ArrayList<>();
        customers.add(new Customer(1, "Alice", 65, 12000, 7.5));
        customers.add(new Customer(2, "Bob", 45, 9500, 8.2));
        customers.add(new Customer(3, "Charlie", 70, 10500, 9.0));

        List<Loan> loans = new ArrayList<>();
        loans.add(new Loan(1, LocalDate.now().plusDays(10)));
        loans.add(new Loan(2, LocalDate.now().plusDays(35)));
        loans.add(new Loan(3, LocalDate.now().plusDays(25)));

       
        for (Customer customer : customers) {
            if (customer.age > 60) {
                customer.loanInterestRate -= 1.0;
                System.out.println("Applied 1% discount for " + customer.name + ". New Rate: " + customer.loanInterestRate + "%");
            }
        }

        System.out.println("-----");

               for (Customer customer : customers) {
            if (customer.balance > 10000) {
                customer.isVIP = true;
                System.out.println(customer.name + " is now a VIP.");
            }
        }

        System.out.println("-----");

        LocalDate today = LocalDate.now();
        for (Loan loan : loans) {
            if (!loan.dueDate.isBefore(today) && !loan.dueDate.isAfter(today.plusDays(30))) {
                Customer customer = customers.stream()
                        .filter(c -> c.id == loan.customerId)
                        .findFirst()
                        .orElse(null);
                if (customer != null) {
                    System.out.println("Reminder: " + customer.name + ", your loan is due on " + loan.dueDate);
                }
            }
        }
    }
}
