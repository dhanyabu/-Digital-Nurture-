package maven3.junit1;

public interface ExternalApi {
    String getData();
}