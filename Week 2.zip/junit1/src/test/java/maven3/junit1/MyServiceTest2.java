package maven3.junit1;

import static org.mockito.Mockito.*;

import org.junit.Test;  // JUnit 4 import
import org.mockito.Mockito;

public class MyServiceTest2 {

    @Test
    public void testVerifyInteraction() {
        ExternalApi mockApi = Mockito.mock(ExternalApi.class);
        MyService service = new MyService(mockApi);
        service.fetchData();
        verify(mockApi).getData(); // Verifies that getData() was called
    }
}
