package storedProcedures;

import java.util.*;

class Account {
    int accountId;
    String type; 
    double balance;

    Account(int accountId, String type, double balance) {
        this.accountId = accountId;
        this.type = type;
        this.balance = balance;
    }
}