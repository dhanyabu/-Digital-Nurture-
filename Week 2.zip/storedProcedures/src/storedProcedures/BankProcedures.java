package storedProcedures;

import java.util.*;

public class BankProcedures {

    
    public static void processMonthlyInterest(List<Account> accounts) {
        for (Account account : accounts) {
            if (account.type.equalsIgnoreCase("savings")) {
                account.balance += account.balance * 0.01; 
                System.out.println("Applied interest to Account ID: " + account.accountId + ", New Balance: " + account.balance);
            }
        }
    }

  
    public static void updateEmployeeBonus(List<Employee> employees, String department, double bonusPercent) {
        for (Employee employee : employees) {
            if (employee.department.equalsIgnoreCase(department)) {
                double bonus = employee.salary * bonusPercent / 100;
                employee.salary += bonus;
                System.out.println("Updated Salary for Employee ID: " + employee.empId + ", New Salary: " + employee.salary);
            }
        }
    }

   
    public static void transferFunds(List<Account> accounts, int fromAccountId, int toAccountId, double amount) {
        Account from = null, to = null;
        for (Account acc : accounts) {
            if (acc.accountId == fromAccountId) from = acc;
            if (acc.accountId == toAccountId) to = acc;
        }

        if (from == null || to == null) {
            System.out.println("Error: One of the accounts does not exist.");
            return;
        }

        if (from.balance >= amount) {
            from.balance -= amount;
            to.balance += amount;
            System.out.println("Transferred $" + amount + " from Account " + from.accountId + " to Account " + to.accountId);
        } else {
            System.out.println("Transfer failed: Insufficient balance in Account " + from.accountId);
        }
    }


    public static void main(String[] args) {
      
        List<Account> accounts = new ArrayList<>();
        accounts.add(new Account(101, "savings", 5000));
        accounts.add(new Account(102, "current", 3000));
        accounts.add(new Account(103, "savings", 8000));

        List<Employee> employees = new ArrayList<>();
        employees.add(new Employee(1, "IT", 50000, 4));
        employees.add(new Employee(2, "HR", 45000, 3));
        employees.add(new Employee(3, "IT", 55000, 5));

        
        System.out.println("=== Processing Monthly Interest ===");
        processMonthlyInterest(accounts);

        System.out.println("\n=== Updating Employee Bonus ===");
        updateEmployeeBonus(employees, "IT", 10); 

        System.out.println("\n=== Transferring Funds ===");
        transferFunds(accounts, 101, 102, 1000); 
    }
}