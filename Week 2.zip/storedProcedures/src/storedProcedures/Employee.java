package storedProcedures;

class Employee {
    int empId;
    String department;
    double salary;
    int performanceRating; 

    Employee(int empId, String department, double salary, int performanceRating) {
        this.empId = empId;
        this.department = department;
        this.salary = salary;
        this.performanceRating = performanceRating;
    }
}